import json
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib.auth import authenticate, login, logout
from .models import *
from shop.form import CustomUserForm


def home(request):
    food = Food.objects.filter(trending=1)
    return render(request, "shop/index.html", {"food": food})


def logout_page(request):
    if request.user.is_authenticated:
        logout(request)
        messages.success(request, "Logged out successfully")
    return redirect('/')


def login_page(request):
    if request.user.is_authenticated:
        return redirect("/")
    else:
        if request.method == "POST":
            name = request.POST.get('username')
            pwd = request.POST.get('password')
            user = authenticate(request, username=name, password=pwd)
            if user is not None:
                login(request, user)
                messages.success(request, "Logged in successfully")
                return redirect('/')
            else:
                messages.error(request, "Invalid username or password")
        return render(request, "shop/login.html")


def register(request):
    form = CustomUserForm()
    if request.method == 'POST':
        form = CustomUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Registration successful, you can login now!")
            return redirect('/login')
    return render(request, "shop/register.html", {'form': form})


def collections(request):
    category = Category.objects.filter(status=0)
    return render(request, "shop/collections.html", {"category": category})


def collectionsview(request, name):
    if Category.objects.filter(name=name, status=0).exists():
        food = Food.objects.filter(category__name=name, status=0)
        return render(request, "shop/food/index.html", {"food": food, "category_name": name})
    else:
        messages.warning(request, "No such food found")
        return redirect('collections')


def food_details(request, cname, pname):
    if Category.objects.filter(name=cname, status=0).exists():
        if Food.objects.filter(name=pname, status=0).exists():
            foods = Food.objects.filter(name=pname, status=0).first()
            return render(request, "shop/food/food_details.html", {"foods": foods})
        else:
            messages.error(request, "No such food found")
            return redirect('collectionsview', name=cname)
    else:
        messages.error(request, "No such category found")
        return redirect('collections')

def add_to_cart(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        if request.user.is_authenticated:
            data = json.loads(request.body)  
            food_id = data.get('pid')
            food_qty = int(data.get('food_qty'))

            try:
                food_status = Food.objects.get(id=food_id)  
            except Food.DoesNotExist:
                return JsonResponse({'status': 'Food item not found'}, status=404)

            # Check if item already in cart
            if Cart.objects.filter(user=request.user, food=food_status).exists():  
                return JsonResponse({'status': 'Item already in cart'}, status=200)
            else:
                # Check stock
                if food_status.quantity >= food_qty:  
                    Cart.objects.create(
                        user=request.user,  
                        food=food_status,   # ✅ pass object, not ID
                        food_qty=food_qty
                    )
                    return JsonResponse({'status': 'Item added to cart'}, status=200)
                else:
                    return JsonResponse({'status': 'Only limited stock available'}, status=200)

        else:
            return JsonResponse({'status': 'Login to add cart'}, status=401)
    else:
        return JsonResponse({'status': 'Invalid Access'}, status=400)


def cart_page(request):
    if request.user.is_authenticated:
        cart = Cart.objects.filter(user=request.user)
        return render(request, "shop/cart.html", {"cart": cart})
    else:
        return redirect("/")
def remove_cart(request,cid):
    cartitem=Cart.objects.get(id=cid)
    cartitem.delete()
    return redirect("/cart")