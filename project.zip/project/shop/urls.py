from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('register', views.register, name="register"),
    path('login', views.login_page, name="login"),
    path('logout', views.logout_page, name="logout"),
    path('collections', views.collections, name="collections"),
    path('collections/<str:name>', views.collectionsview, name="collectionsview"),
    path('collections/<str:cname>/<str:pname>', views.food_details, name="food_details"),
    path('addtocart', views.add_to_cart, name="addtocart"),
    path('cart', views.cart_page, name="cart"),
    path('removecart/<int:cid>', views.remove_cart, name="removecart"),
]

